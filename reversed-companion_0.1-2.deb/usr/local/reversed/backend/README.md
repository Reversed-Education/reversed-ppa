# hummingbird-backend

This is the backend providing the websocket datastreaming using flask and flask_socketio.

## run

```
$ python3 app.py
```

## development

```
$ FLASK_ENV=development python3 app.py
```

After having installed a new dependency via pip3, run

```
$ pip3 freeze > requirements.txt
```
