#!/usr/bin/env python3
# -*- mode: python; coding: utf-8 -*-
# (c) Martin Wudenka mailto:Martin.Wudenka@gmx.de
import os
import json
import bson
from time import time, sleep
from flask_socketio import SocketIO, emit
import eventlet
import serial
eventlet.monkey_patch(socket=True)

try:
    redis = "redis://{}".format(os.environ['REDIS_HOST'])
except KeyError:
    redis = "redis://localhost"

socketio = SocketIO(async_mode='eventlet', message_queue=redis,
                    logger=False, engineio_logger=False)

print("Redis URL:", redis)

if __name__ == "__main__":
    s = serial.Serial('/dev/ttyUSB0', 115200)

    if s.isOpen():
        s.close()
    s.open()

    while True:
        while s.in_waiting:
            response = s.read_until(
                terminator=serial.CR + serial.LF, size=None)
            if response is not "":
                # print("response", response)
                try:
                    parsed = bson.loads(response.rstrip())
                except:
                    continue

                # print("parsed", parsed)

                payload = dict()

                if 't' in parsed:
                    payload['time'] = parsed['t'] / 1000
                if 'r' in parsed:
                    payload['roll'] = parsed['r'] / 100
                if 'p' in parsed:
                    payload['pitch'] = parsed['p'] / 100
                if 'y' in parsed:
                    payload['yaw'] = parsed['y'] / 100
                if 'cl' in parsed:
                    payload['rpm_left'] = parsed['cl'] / 800 * 1000 * 11.1
                if 'cr' in parsed:
                    payload['rpm_right'] = parsed['cr'] / 800 * 1000 * 11.1

                socketio.emit(
                    'drone', {'type': 'physicsStates/PUSH', 'payload': payload})

        sleep(0.01)
