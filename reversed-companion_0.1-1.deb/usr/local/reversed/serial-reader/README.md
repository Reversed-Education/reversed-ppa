# dummy data

Use this to push data to the redis messaging queue. This way you can fake data coming from the micro controller.
