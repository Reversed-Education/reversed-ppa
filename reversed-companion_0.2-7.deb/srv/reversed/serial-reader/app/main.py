#!/usr/bin/env python3
# -*- mode: python; coding: utf-8 -*-
# (c) Martin Wudenka mailto:Martin.Wudenka@gmx.de
import os
import json
from cobs import cobs
import msgpack
from time import time, sleep
from flask_socketio import SocketIO, emit
import eventlet
import serial
import math
eventlet.monkey_patch(socket=True)

try:
    redis = "redis://{}".format(os.environ['REDIS_HOST'])
except KeyError:
    redis = "redis://localhost"

socketio = SocketIO(async_mode='eventlet', message_queue=redis,
                    logger=False, engineio_logger=False)

print("Redis URL:", redis)

if __name__ == "__main__":
    try:
        s = serial.Serial('/dev/serial0', 115200)
    except (serial.serialutil.SerialException, PermissionError) as e:
        print("Could not connect to port")
        socketio.emit(
            'drone', {'type': 'msg', 'payload': "[serial-reader]: could not connect to port"})
        exit()

    while not s.isOpen():
        try:
            s.open()
        except serial.serialutil.SerialException as e:
            print("Could not open port")
            socketio.emit(
                'drone', {'type': 'msg', 'payload': "[serial-reader]: could not open port. Will retry"})

        sleep(0.5)

    while True:

        while s.in_waiting:
            response = s.read_until(terminator=b'\x00', size=100)
            if response is not "":
                try:
                    response = cobs.decode(response[:-1])
                    msg = msgpack.unpackb(response, raw=True)

                    payload = dict()

                    if isinstance(msg, dict) and "msg" in msg:
                        socketio.emit(
                            'drone', {'type': 'msg', 'payload': msg["msg"]})
                    if isinstance(msg, list):
                        if(len(msg) >= 13):
                            payload['time'] = msg[0] / 1000.0
                            payload['roll'] = msg[1] * 180.0 / math.pi
                            payload['pitch'] = msg[2] * 180.0 / math.pi
                            payload['yaw'] = msg[3] * 180.0 / math.pi
                            payload['vroll'] = msg[4] * 180.0 / math.pi
                            payload['vpitch'] = msg[5] * 180.0 / math.pi
                            payload['vyaw'] = msg[6] * 180.0 / math.pi
                            payload['vx'] = msg[7]
                            payload['vy'] = msg[8]
                            payload['vz'] = msg[9]
                            payload['ax'] = msg[10]
                            payload['ay'] = msg[11]
                            payload['az'] = msg[12]

                            socketio.emit(
                                'drone', {'type': 'measurement', 'payload': payload})
                        else:
                            print("Array is too short")
                            socketio.emit(
                                'drone', {'type': 'msg', 'payload': "[serial-reader]: array is too short"})
                except (cobs.DecodeError, msgpack.ExtraData, msgpack.UnpackValueError) as e:
                    print("Decode error")
                    socketio.emit(
                        'drone', {'type': 'msg', 'payload': "[serial-reader]: could not decode message"})

        sleep(0.01)
