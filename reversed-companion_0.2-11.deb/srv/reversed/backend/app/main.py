#!/usr/bin/env python3
# -*- mode: python; coding: utf-8 -*-
# (c) Martin Wudenka mailto:Martin.Wudenka@gmx.de
from flask_gs import VGlobalStorage
from flask_socketio import SocketIO, emit, send
from flask import Flask, jsonify, request
import os
import eventlet
eventlet.monkey_patch(socket=True)


app = Flask('hummingbird-backend')
app.config['SECRET_KEY'] = 'should be a random string'

GS = VGlobalStorage(app)

try:
    host = os.environ['FLASK_HOST']
except KeyError:
    host = '127.0.0.1'

try:
    port = os.environ['FLASK_PORT']
except KeyError:
    port = 3000

try:
    development = os.environ['FLASK_ENV'] == "development"
except KeyError:
    development = False

try:
    redis = "redis://{}".format(os.environ['REDIS_HOST'])
except KeyError:
    redis = "redis://127.0.0.1"

print("Redis url", redis)

socketio = SocketIO(app, async_mode='eventlet', message_queue=redis,
                    path='/api/socket', logger=development, engineio_logger=development)


@app.route('/')
@app.route('/index')
def index():
    return jsonify(msg='Howdy!')


@socketio.on('connect')
def connect():
    if GS.getData('sid'):
        send("Someone else is already connected", sid=request.sid)
        print("Refused connection")
        return False

    print('Client connected')
    GS.setData('sid', request.sid)


@socketio.on('disconnect')
def disconnect():
    sid = GS.getData('sid')

    if sid == request.sid:
        print('Client disconnected')
        GS.setData('sid', None)


if __name__ == "__main__":
    socketio.run(app, host=host, port=port,
                 debug=development, log_output=development)
